.. image:: https://img.shields.io/pypi/v/jaraco.itertools.svg
   :target: https://pypi.org/project/jaraco.itertools

.. image:: https://img.shields.io/pypi/pyversions/jaraco.itertools.svg

.. image:: https://img.shields.io/pypi/dm/jaraco.itertools.svg

.. image:: https://img.shields.io/travis/jaraco/jaraco.itertools/master.svg
   :target: http://travis-ci.org/jaraco/jaraco.itertools


